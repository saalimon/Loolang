# Thai Spoonerism

This is a simple package for create simple Spoonerism in Thai Language.